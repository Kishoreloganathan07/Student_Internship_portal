
import { useEffect, useState } from 'react';
import './App.css';

const API = '/api';

function App() {
  const [internships, setInternships] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState(null);
  const [studentName, setStudentName] = useState('');
  const [studentEmail, setStudentEmail] = useState('');
  const [resumeLink, setResumeLink] = useState('');
  const [coverLetter, setCoverLetter] = useState('');
  const [message, setMessage] = useState('');
  const [view, setView] = useState('internships');
  const [applications, setApplications] = useState([]);
  const [submitting, setSubmitting] = useState(false);

  async function loadInternships(query = '') {
    setLoading(true);
    setError('');

    try {
      const response = await fetch(
        `${API}/internships?search=${encodeURIComponent(query)}`
      );

      if (!response.ok) throw new Error('Could not load internships');

      setInternships(await response.json());
    } catch {
      setError('Unable to connect to the backend. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadInternships();
  }, []);

  async function submitApplication(event) {
    event.preventDefault();
    setMessage('');
    setSubmitting(true);

    try {
      const response = await fetch(`${API}/applications`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName,
          studentEmail,
          internship: selected._id,
          resumeLink,
          coverLetter,
        }),
      });

      const data = await response.json();

      if (!response.ok) throw new Error(data.error || 'Application failed');

      setMessage('Application submitted successfully!');
      setSelected(null);
      setResumeLink('');
      setCoverLetter('');
    } catch (err) {
      setMessage(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  async function loadApplications(event) {
    event.preventDefault();
    setMessage('');

    if (!studentEmail.trim()) {
      setMessage('Enter your email address first.');
      return;
    }

    try {
      const response = await fetch(
        `${API}/applications?email=${encodeURIComponent(studentEmail)}`
      );

      if (!response.ok) throw new Error('Could not load applications');

      setApplications(await response.json());
      setView('applications');
    } catch (err) {
      setMessage(err.message);
    }
  }

  return (
    <div className="portal">
      <header className="topbar">
        <a className="brand" href="#" onClick={() => setView('internships')}>
          <span className="brand-icon">S</span>
          Intern<span className="brand-accent">Connect</span>
        </a>

        <nav>
          <button
            className={view === 'internships' ? 'nav-link active' : 'nav-link'}
            onClick={() => setView('internships')}
          >
            Find Internships
          </button>
          <button
            className={view === 'applications' ? 'nav-link active' : 'nav-link'}
            onClick={() => setView('applications')}
          >
            My Applications
          </button>
        </nav>

        <button
          className="profile-button"
          onClick={() => document.getElementById('student-email')?.focus()}
        >
          Student Portal ↗
        </button>
      </header>

      <main>
        <section className="hero">
          <div className="hero-content">
            <span className="eyebrow">YOUR CAREER STARTS HERE</span>
            <h1>
              Find your next
              <br />
              <span>big opportunity.</span>
            </h1>
            <p>
              Discover internships, build real-world skills, and take
              the first step toward your dream career.
            </p>

            <div className="hero-stats">
              <div>
                <strong>{internships.length}+</strong>
                <span>Open listings</span>
              </div>
              <div>
                <strong>Career</strong>
                <span>Growth opportunities</span>
              </div>
            </div>
          </div>

          <div className="hero-art" aria-hidden="true">
            <div className="orbit orbit-one" />
            <div className="orbit orbit-two" />
            <div className="art-card">
              <span className="art-emoji">🚀</span>
              <h3>Your future, unlocked.</h3>
              <p>Learn · Build · Grow</p>
              <div className="art-progress">
                <span />
              </div>
              <small>Start your journey today</small>
            </div>
            <div className="floating-badge">✦ New opportunities</div>
          </div>
        </section>

        <section className="search-section">
          <div>
            <span className="eyebrow">EXPLORE OPPORTUNITIES</span>
            <h2>Find the right internship</h2>
            <p>Search by role, company, location, or skill.</p>
          </div>

          <form
            className="search-box"
            onSubmit={(event) => {
              event.preventDefault();
              setView('internships');
              loadInternships(search);
            }}
          >
            <span>⌕</span>
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="e.g. Software Developer, Python..."
              aria-label="Search internships"
            />
            <button type="submit">Search</button>
          </form>
        </section>

        {message && (
          <div className="notice" role="status">
            {message}
            <button onClick={() => setMessage('')}>×</button>
          </div>
        )}

        {view === 'internships' ? (
          <section className="listing-section">
            <div className="section-heading">
              <div>
                <h2>Latest opportunities</h2>
                <p>Discover roles that match your ambitions.</p>
              </div>
              <span className="result-count">
                {internships.length} opportunities
              </span>
            </div>

            {loading ? (
              <div className="empty-state">Loading internships...</div>
            ) : error ? (
              <div className="empty-state">
                <h3>Something went wrong</h3>
                <p>{error}</p>
                <button className="primary-button" onClick={() => loadInternships(search)}>
                  Try again
                </button>
              </div>
            ) : internships.length === 0 ? (
              <div className="empty-state">
                <span className="empty-icon">✦</span>
                <h3>No internships found yet</h3>
                <p>
                  Add your first internship through the backend API,
                  then refresh this page.
                </p>
              </div>
            ) : (
              <div className="internship-grid">
                {internships.map((internship) => (
                  <article className="internship-card" key={internship._id}>
                    <div className="card-top">
                      <div className="company-avatar">
                        {internship.company?.charAt(0).toUpperCase() || 'C'}
                      </div>
                      <span className="open-badge">● Open</span>
                    </div>

                    <h3>{internship.title}</h3>
                    <p className="company-name">{internship.company}</p>

                    <div className="card-meta">
                      <span>⌖ {internship.location}</span>
                      <span>◷ {internship.duration}</span>
                    </div>

                    <div className="stipend">
                      <span>Stipend</span>
                      <strong>{internship.stipend}</strong>
                    </div>

                    <p className="description">
                      {internship.description}
                    </p>

                    <div className="skills">
                      {(internship.skills || []).slice(0, 4).map((skill) => (
                        <span key={skill}>{skill}</span>
                      ))}
                    </div>

                    <button
                      className="apply-button"
                      onClick={() => {
                        setSelected(internship);
                        setMessage('');
                      }}
                    >
                      Apply now <span>↗</span>
                    </button>
                  </article>
                ))}
              </div>
            )}
          </section>
        ) : (
          <section className="listing-section">
            <div className="section-heading">
              <div>
                <h2>My applications</h2>
                <p>Track your submitted internship applications.</p>
              </div>
            </div>

            <form className="application-search" onSubmit={loadApplications}>
              <input
                id="student-email"
                type="email"
                required
                value={studentEmail}
                onChange={(event) => setStudentEmail(event.target.value)}
                placeholder="Enter your application email"
              />
              <button className="primary-button" type="submit">
                Find applications
              </button>
            </form>

            {applications.length === 0 ? (
              <div className="empty-state">
                Your applications will appear here after you search by email.
              </div>
            ) : (
              <div className="application-list">
                {applications.map((application) => (
                  <article className="application-row" key={application._id}>
                    <div>
                      <h3>{application.internship?.title || 'Internship'}</h3>
                      <p>
                        {application.internship?.company || 'Company'} ·{' '}
                        {application.studentEmail}
                      </p>
                    </div>
                    <span className="status-badge">{application.status}</span>
                  </article>
                ))}
              </div>
            )}
          </section>
        )}
      </main>

      <footer>
        <a className="brand footer-brand" href="#">
          <span className="brand-icon">S</span>
          Intern<span className="brand-accent">Connect</span>
        </a>
        <p>Connecting student talent with real-world opportunities.</p>
        <span>Student Internship Portal · 2026</span>
      </footer>

      {selected && (
        <div
          className="modal-backdrop"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setSelected(null);
          }}
        >
          <section
            className="application-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="application-title"
          >
            <button
              className="modal-close"
              onClick={() => setSelected(null)}
              aria-label="Close application form"
            >
              ×
            </button>
            <span className="eyebrow">TAKE THE NEXT STEP</span>
            <h2 id="application-title">Apply for this internship</h2>
            <p className="modal-role">
              {selected.title} · {selected.company}
            </p>

            <form onSubmit={submitApplication}>
              <label>
                Full name *
                <input
                  required
                  value={studentName}
                  onChange={(event) => setStudentName(event.target.value)}
                  placeholder="Enter your full name"
                />
              </label>
              <label>
                Email address *
                <input
                  required
                  type="email"
                  value={studentEmail}
                  onChange={(event) => setStudentEmail(event.target.value)}
                  placeholder="you@example.com"
                />
              </label>
              <label>
                Resume link
                <input
                  type="url"
                  value={resumeLink}
                  onChange={(event) => setResumeLink(event.target.value)}
                  placeholder="https://..."
                />
              </label>
              <label>
                Why are you a good fit?
                <textarea
                  rows="3"
                  value={coverLetter}
                  onChange={(event) => setCoverLetter(event.target.value)}
                  placeholder="Tell the company about your interest..."
                />
              </label>
              <button
                className="primary-button submit-button"
                type="submit"
                disabled={submitting}
              >
                {submitting ? 'Submitting...' : 'Submit application →'}
              </button>
            </form>
          </section>
        </div>
      )}
    </div>
  );
}

export default App;
