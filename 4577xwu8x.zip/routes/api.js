
const express = require('express');
const router = express.Router();

const Internship = require('../models/Internship');
const Application = require('../models/Application');

// Test API
router.get('/health', (req, res) => {
  res.json({ message: 'Student Internship Portal API is running!' });
});

// Get all internships and search
router.get('/internships', async (req, res) => {
  try {
    const filter = { status: 'Open' };

    if (req.query.search) {
      const search = req.query.search.trim();
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { company: { $regex: search, $options: 'i' } },
        { location: { $regex: search, $options: 'i' } },
        { skills: { $regex: search, $options: 'i' } },
      ];
    }

    const internships = await Internship.find(filter).sort({
      createdAt: -1,
    });

    res.json(internships);
  } catch (error) {
    res.status(500).json({ error: 'Unable to fetch internships' });
  }
});

// Add an internship
router.post('/internships', async (req, res) => {
  try {
    const { title, company, description } = req.body;

    if (!title || !company || !description) {
      return res.status(400).json({
        error: 'Title, company, and description are required',
      });
    }

    const internship = await Internship.create(req.body);
    res.status(201).json(internship);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Submit an application
router.post('/applications', async (req, res) => {
  try {
    const {
      studentName,
      studentEmail,
      internship: internshipId,
      resumeLink,
      coverLetter,
    } = req.body;

    if (!studentName || !studentEmail || !internshipId) {
      return res.status(400).json({
        error: 'Student name, email, and internship ID are required',
      });
    }

    const internship = await Internship.findOne({
      _id: internshipId,
      status: 'Open',
    });

    if (!internship) {
      return res.status(404).json({
        error: 'Internship not found or no longer open',
      });
    }

    const application = await Application.create({
      studentName,
      studentEmail,
      internship: internshipId,
      resumeLink,
      coverLetter,
    });

    res.status(201).json({
      message: 'Application submitted successfully',
      application,
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({
        error: 'Duplicate application',
      });
    }

    res.status(400).json({ error: error.message });
  }
});

// View applications for a student by email
router.get('/applications', async (req, res) => {
  try {
    const { email } = req.query;

    const filter = email
      ? { studentEmail: email.toLowerCase().trim() }
      : {};

    const applications = await Application.find(filter)
      .populate('internship')
      .sort({ createdAt: -1 });

    res.json(applications);
  } catch (error) {
    res.status(500).json({ error: 'Unable to fetch applications' });
  }
});

// Update an application status
router.patch('/applications/:id/status', async (req, res) => {
  try {
    const allowedStatuses = [
      'Pending',
      'Shortlisted',
      'Rejected',
      'Selected',
    ];

    if (!allowedStatuses.includes(req.body.status)) {
      return res.status(400).json({ error: 'Invalid application status' });
    }

    const application = await Application.findByIdAndUpdate(
      req.params.id,
      { status: req.body.status },
      { new: true, runValidators: true }
    );

    if (!application) {
      return res.status(404).json({ error: 'Application not found' });
    }

    res.json(application);
  } catch (error) {
    res.status(400).json({ error: 'Unable to update application status' });
  }
});

module.exports = router;
